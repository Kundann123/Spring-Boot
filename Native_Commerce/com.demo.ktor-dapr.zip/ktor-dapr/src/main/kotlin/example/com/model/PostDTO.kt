package example.com.model

data class PostDTO(
    val userId: Int,
    val id: Int,
    val title: String,
    val body: String
)
