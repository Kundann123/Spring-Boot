rootProject.name = "com.demo.ktor-dapr"
