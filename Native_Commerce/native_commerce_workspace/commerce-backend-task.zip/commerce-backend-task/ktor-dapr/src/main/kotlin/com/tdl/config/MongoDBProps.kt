package com.tdl.config

object MongoDBProps {
    var mongoDBProps: MongoDBPropDTO = MongoDBPropDTO()
}