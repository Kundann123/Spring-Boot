package com.tdl.util

object ErrorConstant {
    const val INVALID_REQUEST_STRUCTURE_ERR_MSG = "Invalid Request"
    const val CLIENT_SERIALIZATION_ERR_MSG = "Unable To Serialize Client Response"
}
